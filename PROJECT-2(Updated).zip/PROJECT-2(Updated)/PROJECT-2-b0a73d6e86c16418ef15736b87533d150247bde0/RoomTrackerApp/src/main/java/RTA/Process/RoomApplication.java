/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package RTA.Process;

/**
 *
 * @author musot
 */
import java.awt.*;
import RTA.dao.StudentDAO;
import java.io.File;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import javax.swing.*;

public class RoomApplication extends JFrame {

    private JPanel pnlSouth;
    private JButton btnUpload, btnproof, btnadd, btnApply;
    private JComboBox<String> cbostatus, cbotype;
    private JComboBox<String> cboResidence;
    private JTextField txtSID, txtstart;
    private JLabel idpath, nsfaspath, proofpath, lblimage;

    public RoomApplication() {
        super("Application Form");
//Setting layout
        setLayout(new BorderLayout(10, 10));
        setLocationRelativeTo(null);
//adding image
        lblimage = new JLabel();
        lblimage.setHorizontalAlignment(SwingConstants.CENTER);
        lblimage.setIcon(new ImageIcon("src/main/java/RTA/Process/resource/cput logo.jpeg"));
        add(lblimage, BorderLayout.WEST);

//creating a JPanel and setting a layout for how the form will look 
        pnlSouth = new JPanel();
        pnlSouth.setLayout(new GridLayout(18, 2, 10, 10));

        JLabel lblRes = new JLabel("Select Residence:");
        cboResidence = new JComboBox<>(new String[]{"Select", "NMJ", "VOGUE", "CAPE STATION", "CAPE SUITES", "CATSVILLE"});

        JLabel lblroom = new JLabel("Room Type: ");
        cbotype = new JComboBox<>(new String[]{"Select", "Single", "Double", "Sharing"});

        JLabel lbldate = new JLabel("Start Date");
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        String today = LocalDate.now().format(formatter);
        txtstart = new JTextField(today);
        txtstart.setEditable(true);

        JLabel lblIDD = new JLabel("ID Document ");
        btnUpload = new JButton("Choose File");
        idpath = new JLabel("No file chosen");

        JLabel lblnsfas = new JLabel("Application Proof");
        btnproof = new JButton("Choose File");
        proofpath = new JLabel("No file chosen");

        JLabel lblstatus = new JLabel("Funding Status");
        String[] status = {"Select", "Funded", "Not Funded", "Pending"};
        cbostatus = new JComboBox<>(status);

        btnApply = new JButton("Apply");

        pnlSouth.add(lblroom);
        pnlSouth.add(cbotype);

        pnlSouth.add(lbldate);
        pnlSouth.add(txtstart);

        pnlSouth.add(lblIDD);
        pnlSouth.add(btnUpload);
        pnlSouth.add(idpath);

        pnlSouth.add(lblnsfas);
        pnlSouth.add(btnproof);
        pnlSouth.add(proofpath);

        pnlSouth.add(lblstatus);
        pnlSouth.add(cbostatus);

        pnlSouth.add(btnApply);

        add(pnlSouth, BorderLayout.CENTER);

        btnUpload.addActionListener(e -> chooseFile(idpath));

        btnproof.addActionListener(e -> chooseFile(proofpath));

        btnApply.addActionListener(e -> {
            StudentDAO studentDAO = new StudentDAO();
            studentDAO.addStudent(txtSID.getText(), "TempFirst", "TempLast", "Student@example.com", "0123456789");
            JOptionPane.showMessageDialog(this, "Application Submitted & saved!");
            dispose();
            new ApplicationSubmitted().setVisible(true);

        });
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    private void chooseFile(JLabel targetLabel) {
        JFileChooser fileChooser = new JFileChooser();
        int result = fileChooser.showOpenDialog(this);
        if (result == JFileChooser.APPROVE_OPTION) {
            File selectedFile = fileChooser.getSelectedFile();
            targetLabel.setText(selectedFile.getAbsolutePath());
        } else {
            targetLabel.setText("No file chosen");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new RoomApplication().setVisible(true));
    }
}
